
import React from "react";
import { Phone, Mail, MapPin } from "lucide-react";

export default function OkavangoPathwaysHome() {
  return (
    <div className="min-h-screen bg-white text-gray-800 p-4 md:p-8">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-green-800 mb-2">
          Okavango Pathways Travel
        </h1>
        <p className="text-lg text-gray-600">
          Explore Botswana. Book safaris, flights, and more — with local expertise.
        </p>
      </header>

      <section className="mb-10 text-center">
        <h2 className="text-2xl font-bold text-green-700 mb-4">Book Your Adventure</h2>
        <a href="https://forms.gle/YOUR_FORM_LINK" target="_blank" rel="noopener noreferrer">
          <button className="bg-green-700 hover:bg-green-800 text-white px-6 py-2 text-lg rounded-xl">
            Book Now
          </button>
        </a>
      </section>

      <footer className="border-t pt-6 text-center text-sm text-gray-600">
        <div className="flex justify-center gap-4 mb-2">
          <span className="flex items-center gap-1">
            <Phone size={16} /> +267 75756066
          </span>
          <span className="flex items-center gap-1">
            <Mail size={16} /> tshepopheko32@gmail.com
          </span>
          <span className="flex items-center gap-1">
            <MapPin size={16} /> Maun, Botswana
          </span>
        </div>
        <p>&copy; {new Date().getFullYear()} Okavango Pathways Travel. All rights reserved.</p>
      </footer>
    </div>
  );
}
